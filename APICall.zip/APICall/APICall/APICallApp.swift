//
//  APICallApp.swift
//  APICall
//
//  Created by Tech on 2025-03-18.
//

import SwiftUI

@main
struct APICallApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
