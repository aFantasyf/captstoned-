import Foundation

class NetworkManager:ObservableObject{
    
    private let toDoUri = "https://jsonplaceholder.typicode.com/todos"
    @Published var toDos:[ToDo] = []
    
    func fetchToDo(withId id:Int, completionHandler: @escaping(ToDo?) -> Void)->Void{
        
        let url = URL(string: toDoUri+"/\(id)")!
        
        let task = URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            
            if let error = error{
                print("Error fetching data: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else{
                print("Error return from API: \(String(describing: response))")
                return
            }
            
            if let data = data {
                let res = try? JSONDecoder().decode(ToDo.self, from: data)
                completionHandler(res)
            }
        }
        task.resume()
    }
    
    func fetchToDos(completionHandler: @escaping([ToDo]) -> Void)->Void{
        
        let url = URL(string: toDoUri)!
        
        let task = URLSession.shared.dataTask(with: url) {
            (data, response, error) in
            
            if let error = error{
                print("Error fetching data: \(error.localizedDescription)")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else{
                print("Error return from API: \(String(describing: response))")
                return
            }
            
            if let data = data {
                let res = try? JSONDecoder().decode([ToDo].self, from: data)
                self.toDos = res ?? []
                completionHandler(self.toDos)
            }
        }
        task.resume()
    }
}


