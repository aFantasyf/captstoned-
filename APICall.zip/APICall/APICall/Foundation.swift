//
//  Foundation.swift
//  APICall
//
//  Created by Tech on 2025-03-18.
//

import Foundation

struct ToDo: Identifiable, Codable{
    let userId: Int
    let id: Int
    let title: String
    let completed: Bool
    

}
