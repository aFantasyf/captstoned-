//
//  ContentView.swift
//  APICall
//
//  Created by Tech on 2025-03-18.
//

import SwiftUI

struct ContentView: View {
    
    
    @StateObject var networkManager = NetworkManager()
    
    
    var body: some View {
        VStack {
            List(networkManager.toDos){
                toDo in
                HStack{
                    Text(toDo.title)
                }.background(toDo.completed ? .white : .red)
            }.onAppear{
                networkManager.fetchToDos(completionHandler: {toDo
                    in print ("recieved data")
                    
                })
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
